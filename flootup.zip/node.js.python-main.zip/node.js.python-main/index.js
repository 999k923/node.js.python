#!/usr/bin/env node
require('child_process').execSync('bash start.sh', { stdio: 'inherit' });
